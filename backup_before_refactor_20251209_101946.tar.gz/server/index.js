import Fastify from 'fastify'
import cors from '@fastify/cors'
import websocket from '@fastify/websocket'
import multipart from '@fastify/multipart'
import dotenv from 'dotenv'
import fetch from 'node-fetch'
import OSS from 'ali-oss'
import { Readable } from 'stream'
import fs from 'fs'
import path from 'path'

dotenv.config()

// 创建日志目录
const logsDir = path.join(process.cwd(), 'logs')
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true })
}

// 保存请求/响应JSON日志
function saveRequestLog(taskId, type, data) {
  try {
    const timestamp = new Date().toISOString().replace(/:/g, '-')
    const filename = `${taskId}_${type}_${timestamp}.json`
    const filepath = path.join(logsDir, filename)
    fs.writeFileSync(filepath, JSON.stringify(data, null, 2), 'utf-8')
    console.log(`[LOG] 已保存 ${type} 日志: ${filename}`)
  } catch (error) {
    console.error(`[LOG] 保存日志失败:`, error.message)
  }
}

const fastify = Fastify({ logger: true })

await fastify.register(cors, { origin: true })
await fastify.register(websocket)
await fastify.register(multipart, {
  limits: {
    fileSize: Infinity,  // 不限制文件大小
    files: 10  // 最多10个文件
  }
})

// 初始化 OSS 客户端
console.log('[OSS] 初始化 OSS 客户端...')
console.log('[OSS] Endpoint:', process.env.OSS_ENDPOINT)
console.log('[OSS] Bucket:', process.env.OSS_BUCKET)
console.log('[OSS] AccessKeyId:', process.env.OSS_AK ? `${process.env.OSS_AK.substring(0, 8)}...` : 'NOT SET')

const ossClient = new OSS({
  region: process.env.OSS_ENDPOINT?.replace('.aliyuncs.com', '') || 'oss-cn-hangzhou',
  accessKeyId: process.env.OSS_AK,
  accessKeySecret: process.env.OSS_SK,
  bucket: process.env.OSS_BUCKET || 'podi'
})

console.log('[OSS] OSS 客户端初始化完成')

const tasks = new Map()

// 文件上传接口
fastify.post('/api/upload', async (request, reply) => {
  try {
    console.log('[UPLOAD] 收到文件上传请求')
    console.log('[UPLOAD] Headers:', request.headers['content-type'])
    
    const data = await request.file()
    if (!data) {
      console.error('[UPLOAD] 错误: 没有文件')
      return reply.code(400).send({ error: 'No file uploaded' })
    }

    console.log('[UPLOAD] 文件信息:', {
      filename: data.filename,
      mimetype: data.mimetype,
      encoding: data.encoding
    })

    const buffer = await data.toBuffer()
    const filename = `${process.env.OSS_ROOT_PREFIX || 'test'}/${Date.now()}_${data.filename}`
    console.log('[UPLOAD] 文件名:', filename, '大小:', buffer.length, 'bytes', `(${(buffer.length / 1024 / 1024).toFixed(2)} MB)`)

    // 验证 OSS 配置
    if (!process.env.OSS_AK || !process.env.OSS_SK || !process.env.OSS_BUCKET) {
      console.error('[UPLOAD] OSS 配置不完整')
      throw new Error('OSS configuration is incomplete')
    }

    // 上传到 OSS
    console.log('[UPLOAD] 开始上传到 OSS...')
    console.log('[UPLOAD] OSS Bucket:', process.env.OSS_BUCKET)
    console.log('[UPLOAD] OSS Region:', process.env.OSS_ENDPOINT?.replace('.aliyuncs.com', ''))
    
    const result = await ossClient.put(filename, buffer)
    console.log('[UPLOAD] OSS 上传成功:', result.name)
    console.log('[UPLOAD] OSS 响应:', JSON.stringify(result, null, 2))
    
    // 返回公开访问 URL
    const publicUrl = process.env.OSS_PUBLIC_DOMAIN 
      ? `${process.env.OSS_PUBLIC_DOMAIN}/${filename}`
      : result.url
    console.log('[UPLOAD] 返回 URL:', publicUrl)

    reply.send({ 
      url: publicUrl,
      filename: data.filename,
      size: buffer.length
    })
  } catch (error) {
    console.error('[UPLOAD] 上传失败 - 错误类型:', error.name)
    console.error('[UPLOAD] 上传失败 - 错误信息:', error.message)
    console.error('[UPLOAD] 上传失败 - 错误堆栈:', error.stack)
    reply.code(500).send({ error: error.message, type: error.name })
  }
})

// 提交生成任务
fastify.post('/api/submit', async (request, reply) => {
  const payload = request.body
  const taskId = `job_${Date.now()}`
  console.log('[SUBMIT] 收到任务提交:', taskId)
  console.log('[SUBMIT] Payload:', JSON.stringify(payload, null, 2))
  
  tasks.set(taskId, {
    id: taskId,
    status: 'PENDING',
    payload,
    createdAt: Date.now(),
    result: null,
    error: null
  })

  // 异步处理任务
  processTask(taskId, payload).catch(err => {
    console.error('[SUBMIT] 任务处理错误:', err)
    tasks.set(taskId, { ...tasks.get(taskId), status: 'FAILED', error: err.message })
  })

  console.log('[SUBMIT] 任务已创建，返回 taskId:', taskId)
  reply.send({ taskId, status: 'PENDING' })
})

// 查询任务状态
fastify.get('/api/task/:taskId', async (request, reply) => {
  const { taskId } = request.params
  const task = tasks.get(taskId)
  
  if (!task) {
    reply.code(404).send({ error: 'Task not found' })
    return
  }

  reply.send(task)
})

// 处理任务（对接 Nano banana2 pro）
async function processTask(taskId, payload, retryCount = 0) {
  const MAX_RETRIES = 3
  const RETRY_DELAY = 2000
  const REQUEST_TIMEOUT = 30000
  
  console.log(`[TASK ${taskId}] 开始处理任务 (尝试 ${retryCount + 1}/${MAX_RETRIES + 1})`)
  
  const task = tasks.get(taskId)
  tasks.set(taskId, { ...task, status: 'PROCESSING' })

  const apiKey = process.env.NANO_API_KEY
  const apiBase = process.env.NANO_API_BASE || 'https://api.apimart.ai'
  console.log(`[TASK ${taskId}] API Base:`, apiBase)
  console.log(`[TASK ${taskId}] API Key:`, apiKey ? `${apiKey.substring(0, 10)}...` : 'NOT SET')

  // 计算图片比例
  const [width, height] = (payload.global_params?.output_resolution || '3840x2160').split('x').map(Number)
  const aspectRatio = width / height
  let size = '16:9' // 默认
  
  // 计算最接近的比例
  const ratios = {
    '1:1': 1, '2:3': 2/3, '3:2': 3/2, '3:4': 3/4, '4:3': 4/3,
    '4:5': 4/5, '5:4': 5/4, '9:16': 9/16, '16:9': 16/9, '21:9': 21/9
  }
  let minDiff = Infinity
  for (const [key, value] of Object.entries(ratios)) {
    const diff = Math.abs(value - aspectRatio)
    if (diff < minDiff) {
      minDiff = diff
      size = key
    }
  }
  console.log(`[TASK ${taskId}] 分辨率: ${width}x${height}, 比例: ${size}`)

  // 确定分辨率等级
  const maxDim = Math.max(width, height)
  let resolution = '4K'
  if (maxDim <= 1024) resolution = '1K'
  else if (maxDim <= 2048) resolution = '2K'
  console.log(`[TASK ${taskId}] 输出分辨率等级: ${resolution}`)

  // 组装 Nano banana2 API 请求（符合文档格式）
  let processedPrompt = payload.prompt || ''
  
  // ✅ 替换提示词中的 @ref_xxx 占位符
  if (payload.reference_assets && payload.reference_assets.length > 0) {
    payload.reference_assets.forEach((asset, index) => {
      const imageNumber = index + 2  // 主图是第1张，参考图从第2张开始
      const regex = new RegExp(`@${asset.id}`, 'g')
      const replacement = `image ${imageNumber}`
      processedPrompt = processedPrompt.replace(regex, replacement)
      console.log(`[TASK ${taskId}] 替换提示词：@${asset.id} -> ${replacement}`)
    })
  }
  
  // ✅ 替换提示词中的 @颜色 占位符
  if (payload.mask_regions && payload.mask_regions.length > 0) {
    const colorMap = {
      '#FF0000': '红色',
      '#00FF00': '绿色',
      '#0000FF': '蓝色',
      '#FFFF00': '黄色',
      '#00FFFF': '青色',
      '#FF00FF': '品红',
      '#FFFFFF': '白色'
    }
    
    payload.mask_regions.forEach((mask, index) => {
      if (mask.color) {
        const colorName = colorMap[mask.color.toUpperCase()] || mask.color
        // 替换 @颜色 为更明确的描述
        const regex = new RegExp(`@${colorName}`, 'g')
        const replacement = `the ${colorName} marked area`
        processedPrompt = processedPrompt.replace(regex, replacement)
        console.log(`[TASK ${taskId}] 替换提示词：@${colorName} -> ${replacement}`)
      }
    })
  }
  
  // ✅ 替换提示词中的 #mask_N 占位符（保留兼容）
  if (payload.mask_regions && payload.mask_regions.length > 0) {
    payload.mask_regions.forEach((mask, index) => {
      const maskNumber = index + 1
      const regex = new RegExp(`#mask_${maskNumber}`, 'g')
      const replacement = `mask region ${maskNumber}`
      processedPrompt = processedPrompt.replace(regex, replacement)
      console.log(`[TASK ${taskId}] 替换提示词：#mask_${maskNumber} -> ${replacement}`)
    })
  }
  
  console.log(`[TASK ${taskId}] 原始提示词: ${payload.prompt}`)
  console.log(`[TASK ${taskId}] 处理后提示词: ${processedPrompt}`)
  
  const requestBody = {
    model: 'gemini-3-pro-image-preview',
    prompt: processedPrompt,
    size,
    resolution,
    n: 1
  }

  // 添加图片 URL（主图 + 参考图）
  const imageUrls = []
  
  // ✅ 第1张图：主图（base_image）
  if (payload.base_image) {
    imageUrls.push({ url: payload.base_image })
    console.log(`[TASK ${taskId}] 主图 (image 1): ${payload.base_image}`)
  }
  
  // ✅ 第2,3,4...张图：参考图（reference_assets）
  if (payload.reference_assets && payload.reference_assets.length > 0) {
    payload.reference_assets.forEach((asset, index) => {
      imageUrls.push({ url: asset.url })
      console.log(`[TASK ${taskId}] 参考图 (image ${index + 2}): ${asset.url}`)
    })
  }
  
  if (imageUrls.length > 0) {
    requestBody.image_urls = imageUrls
    console.log(`[TASK ${taskId}] 总图片数量: ${imageUrls.length}`)
  }

  // ✅ 优先使用合成的 RGB 蒙版，如果没有则使用第一个蒙版
  if (payload.composite_mask_url) {
    // ✅ 使用 RGB 合成蒙版
    requestBody.mask_url = payload.composite_mask_url
    console.log(`[TASK ${taskId}] 使用 RGB 合成蒙版: ${payload.composite_mask_url}`)
    console.log(`[TASK ${taskId}] 包含 ${payload.mask_regions.length} 个颜色区域`)
  } else if (payload.mask_regions && payload.mask_regions.length > 0) {
    console.log(`[TASK ${taskId}] 蒙版数量: ${payload.mask_regions.length}`)
    
    // API 只支持一个 mask_url，使用第一个蒙版作为主蒙版
    const primaryMask = payload.mask_regions[0]
    if (primaryMask.maskUrl) {
      requestBody.mask_url = primaryMask.maskUrl
      console.log(`[TASK ${taskId}] 主蒙版 URL: ${primaryMask.maskUrl}`)
    }
  }
  
  // ✅ 蒙版信息融入提示词（不使用@符号，使用图片顺序编号）
  if (payload.mask_regions && payload.mask_regions.length > 0) {
    const maskPrompts = []
    payload.mask_regions.forEach((mask, index) => {
      const parts = []
      
      // ✅ 颜色标记（RGB颜色通道）
      if (mask.color) {
        // 找到颜色对应的名称
        const colorMap = {
          '#FF0000': '红色',
          '#00FF00': '绿色',
          '#0000FF': '蓝色',
          '#FFFF00': '黄色',
          '#00FFFF': '青色',
          '#FF00FF': '品红',
          '#FFFFFF': '白色'
        }
        const colorName = colorMap[mask.color.toUpperCase()] || mask.color
        parts.push(`${colorName}区域`)
      }
      
      // 蒙版描述（用户输入的语义信息）
      if (mask.description) {
        parts.push(mask.description)
      }
      
      // 关联的参考图（使用图片顺序编号）
      if (mask.referenceLink && payload.reference_assets) {
        const refAsset = payload.reference_assets.find(a => a.id === mask.referenceLink)
        if (refAsset) {
          const refIndex = payload.reference_assets.indexOf(refAsset)
          // 原图是第1张，参考图从第2张开始
          const imageNumber = refIndex + 2
          parts.push(`use image ${imageNumber} as reference`)
        }
      }
      
      // 动作类型
      const actionMap = {
        'generation': 'generate content',
        'style_transfer': 'apply style',
        'remove': 'remove object'
      }
      if (mask.action) {
        parts.push(actionMap[mask.action] || mask.action)
      }
      
      // 控制模式和强度
      if (mask.controlMode && mask.controlMode !== 'content') {
        parts.push(`${mask.controlMode} mode`)
      }
      if (mask.strength !== undefined && mask.strength !== 1) {
        parts.push(`strength ${mask.strength}`)
      }
      
      // 补充提示词
      if (mask.promptSuffix) {
        parts.push(mask.promptSuffix)
      }
      
      if (parts.length > 0) {
        maskPrompts.push(`In mask region ${index + 1}: ${parts.join(', ')}`)
      }
      
      console.log(`[TASK ${taskId}]   - 蒙版 ${index + 1}: ${parts.join(', ')}`)
    })
    
    // 将蒙版信息追加到原始提示词
    if (maskPrompts.length > 0) {
      const maskSection = '\n\n' + maskPrompts.join('\n')
      requestBody.prompt = (requestBody.prompt || '') + maskSection
      console.log(`[TASK ${taskId}] 增强后的提示词:\n${requestBody.prompt}`)
    }
  }

  console.log(`[TASK ${taskId}] 完整请求体:`, JSON.stringify(requestBody, null, 2))
  
  // ✅ 保存请求JSON日志
  saveRequestLog(taskId, 'request', {
    taskId,
    timestamp: new Date().toISOString(),
    originalPayload: payload,
    apiRequestBody: requestBody
  })

  try {
    // 创建超时控制器
    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT)
    
    console.log(`[TASK ${taskId}] 发送请求到 API...`)
    const response = await fetch(`${apiBase}/v1/images/generations`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody),
      signal: controller.signal
    })
    
    clearTimeout(timeout)
    console.log(`[TASK ${taskId}] API 响应状态: ${response.status} ${response.statusText}`)

    if (!response.ok) {
      const errorText = await response.text().catch(() => '')
      console.error(`[TASK ${taskId}] API 错误响应:`, errorText)
      throw new Error(`API error: ${response.status} ${response.statusText} - ${errorText}`)
    }

    const result = await response.json()
    console.log(`[TASK ${taskId}] API 响应数据:`, JSON.stringify(result, null, 2))
    
    // ✅ 保存响应JSON日志
    saveRequestLog(taskId, 'submit_response', {
      taskId,
      timestamp: new Date().toISOString(),
      status: response.status,
      response: result
    })
    
    // API 返回的是 task_id，需要轮询查询结果
    const apiTaskId = result.data?.[0]?.task_id || result.data?.task_id || result.data?.id
    if (!apiTaskId) {
      console.error(`[TASK ${taskId}] API 响应结构:`, result)
      throw new Error('未能获取 API task_id')
    }
    
    console.log(`[TASK ${taskId}] API 返回 task_id: ${apiTaskId}，开始轮询查询结果...`)
    
    // 轮询查询任务结果
    const pollResult = async () => {
      for (let i = 0; i < 60; i++) {  // 最多轮询60次，共120秒
        await new Promise(resolve => setTimeout(resolve, 2000))  // 每2秒查询1次
        
        console.log(`[TASK ${taskId}] 查询任务状态 (第 ${i + 1} 次)...`)
        // 正确的查询 API endpoint
        const statusResponse = await fetch(`${apiBase}/v1/tasks/${apiTaskId}`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${apiKey}`
          }
        })
        
        if (!statusResponse.ok) {
          console.error(`[TASK ${taskId}] 查询任务失败: ${statusResponse.status}`)
          continue
        }
        
        const statusResult = await statusResponse.json()
        console.log(`[TASK ${taskId}] 任务状态响应:`, JSON.stringify(statusResult, null, 2))
        
        // 兼容两种响应格式：data 为数组或对象
        const taskData = Array.isArray(statusResult.data) ? statusResult.data[0] : statusResult.data
        const taskStatus = taskData?.status
        
        console.log(`[TASK ${taskId}] 解析状态: ${taskStatus}`)
        
        // ✅ 保存轮询响应日志（每10次保存一次，避免过多）
        if (i % 10 === 0 || taskStatus === 'completed' || taskStatus === 'failed') {
          saveRequestLog(taskId, `poll_${i + 1}`, {
            taskId,
            timestamp: new Date().toISOString(),
            pollCount: i + 1,
            status: taskStatus,
            response: statusResult
          })
        }
        
        if (taskStatus === 'completed' || taskStatus === 'success') {
          // 多种 URL 获取方式，完全兼容 API 响应结构
          let imageUrl = null
          
          // 方式1: result.images[0].url[0] (Nano banana2 实际格式)
          if (taskData?.result?.images?.[0]?.url) {
            const urlData = taskData.result.images[0].url
            imageUrl = Array.isArray(urlData) ? urlData[0] : urlData
          }
          
          // 方式2: url 字段 (直接在 taskData 中)
          if (!imageUrl && taskData?.url) {
            imageUrl = Array.isArray(taskData.url) ? taskData.url[0] : taskData.url
          }
          
          // 方式3: image_url 字段
          if (!imageUrl && taskData?.image_url) {
            imageUrl = Array.isArray(taskData.image_url) ? taskData.image_url[0] : taskData.image_url
          }
          
          if (!imageUrl) {
            console.error(`[TASK ${taskId}] 任务完成但未找到图片 URL:`, taskData)
            throw new Error('任务完成但未返回图片 URL')
          }
          
          console.log(`[TASK ${taskId}] 任务完成，图片 URL:`, imageUrl)
          return imageUrl
        } else if (taskStatus === 'failed' || taskStatus === 'error') {
          const errorMsg = taskData?.error || taskData?.message || 'Unknown error'
          throw new Error(`API 任务失败: ${errorMsg}`)
        }
        
        console.log(`[TASK ${taskId}] 任务状态: ${taskStatus}，继续等待...`)
      }
      throw new Error('轮询超时，任务未完成')
    }
    
    const resultUrl = await pollResult()
    console.log(`[TASK ${taskId}] 最终结果 URL:`, resultUrl)
    
    tasks.set(taskId, {
      ...tasks.get(taskId),
      status: 'COMPLETE',
      result: resultUrl
    })
  } catch (error) {
    console.error(`[TASK ${taskId}] 错误 (尝试 ${retryCount + 1}/${MAX_RETRIES + 1}):`, error.message)
    console.error(`[TASK ${taskId}] 错误堆栈:`, error.stack)
    
    // 判断是否需要重试（503、超时、网络错误）
    const shouldRetry = (
      error.message.includes('503') || 
      error.message.includes('timeout') ||
      error.message.includes('ECONNRESET') ||
      error.message.includes('ETIMEDOUT') ||
      error.name === 'AbortError'
    ) && retryCount < MAX_RETRIES
    
    if (shouldRetry) {
      console.log(`[TASK ${taskId}] 将在 ${RETRY_DELAY * (retryCount + 1)}ms 后重试...`)
      await new Promise(resolve => setTimeout(resolve, RETRY_DELAY * (retryCount + 1)))
      return processTask(taskId, payload, retryCount + 1)
    }
    
    console.error(`[TASK ${taskId}] 任务最终失败，不再重试`)
    tasks.set(taskId, {
      ...tasks.get(taskId),
      status: 'FAILED',
      error: error.message,
      retryCount
    })
  }
}

// WebSocket 进度推送
fastify.register(async function (fastify) {
  fastify.get('/ws', { websocket: true }, (connection, req) => {
    connection.socket.on('message', message => {
      const { taskId } = JSON.parse(message.toString())
      
      const interval = setInterval(() => {
        const task = tasks.get(taskId)
        if (!task) {
          clearInterval(interval)
          return
        }

        connection.socket.send(JSON.stringify({
          taskId: task.id,
          status: task.status,
          result: task.result,
          error: task.error
        }))

        if (task.status === 'COMPLETE' || task.status === 'FAILED') {
          clearInterval(interval)
        }
      }, 1000)

      connection.socket.on('close', () => clearInterval(interval))
    })
  })
})

const PORT = process.env.PORT || 3001
fastify.listen({ port: PORT, host: '0.0.0.0' }, (err) => {
  if (err) {
    fastify.log.error(err)
    process.exit(1)
  }
  console.log(`Server running at http://localhost:${PORT}`)
})
