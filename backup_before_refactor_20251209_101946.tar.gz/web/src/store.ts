import { create } from 'zustand'

export type TaskStatus = 'PENDING' | 'PROCESSING' | 'COMPLETE' | 'FAILED'

export interface Task {
  id: string
  title: string
  status: TaskStatus
  resultUrl?: string
  createdAt: number
}

// ✅ 预设蒙版颜色
export const MASK_COLORS = [
  { id: 'red', name: '红色', hex: '#FF0000', rgb: [255, 0, 0] },
  { id: 'green', name: '绿色', hex: '#00FF00', rgb: [0, 255, 0] },
  { id: 'blue', name: '蓝色', hex: '#0000FF', rgb: [0, 0, 255] },
  { id: 'yellow', name: '黄色', hex: '#FFFF00', rgb: [255, 255, 0] },
  { id: 'cyan', name: '青色', hex: '#00FFFF', rgb: [0, 255, 255] },
  { id: 'magenta', name: '品红', hex: '#FF00FF', rgb: [255, 0, 255] },
  { id: 'white', name: '白色', hex: '#FFFFFF', rgb: [255, 255, 255] }
] as const

export type MaskColorId = typeof MASK_COLORS[number]['id']

interface ReferenceAsset { id: string; url: string; preprocess: 'none' | 'foreground_only' }
interface MaskRegion { 
  id: string
  name: string  // 蒙版名称
  description: string  // 用户描述（用于提示词组织）
  path: { points: Array<{ x: number; y: number }> }
  maskData: string
  action: 'generation' | 'style_transfer' | 'remove'
  referenceLink?: string | null
  controlMode: 'content' | 'style' | 'structure'
  strength: number
  promptSuffix?: string  // 已废弃，保留兼容性
  color: string
  label?: string  // 已废弃，保留兼容性
  shape: 'freehand' | 'rectangle' | 'circle' | 'polygon'
  visible: boolean  // 是否可见
  createdAt: number  // 创建时间
  updatedAt: number  // 更新时间
}
interface AppState {
  baseImage?: string
  baseMeta?: { width: number; height: number }
  materials: ReferenceAsset[]
  outputResolution: string
  tasks: Task[]
  setBaseImage: (url: string) => void
  setBaseMeta: (meta: { width: number; height: number }) => void
  addMaterials: (assets: ReferenceAsset[]) => void
  removeMaterial: (id: string) => void
  setOutputResolution: (res: string) => void
  addTask: (task: Task) => void
  updateTask: (id: string, partial: Partial<Task>) => void
  masks: MaskRegion[]
  selectedMaskId?: string
  currentMaskColor: string  // ✅ 新增：当前选中的蒙版颜色
  setCurrentMaskColor: (color: string) => void  // ✅ 新增
  addMask: (mask: MaskRegion) => void
  selectMask: (id: string) => void
  updateMask: (id: string, partial: Partial<MaskRegion>) => void
  removeMask: (id: string) => void
  toggleMaskVisibility: (id: string) => void  // 切换可见性
  clearAllMasks: () => void  // 清空所有蒙版
  prompt?: string
  model?: string
  setPrompt: (p: string) => void
  setModel: (m: string) => void
}

export const useAppStore = create<AppState>((set) => ({
  baseImage: undefined,
  baseMeta: undefined,
  materials: [],
  outputResolution: '3840x2160',
  tasks: [],
  masks: [],
  selectedMaskId: undefined,
  currentMaskColor: MASK_COLORS[0].hex,  // ✅ 默认红色
  prompt: '',
  model: 'banana2-pro',
  setBaseImage: (url: string) => set({ baseImage: url }),
  setBaseMeta: (meta) => set({ baseMeta: meta }),
  addMaterials: (assets) => set((s) => ({ materials: [...s.materials, ...assets] })),
  removeMaterial: (id: string) => set((s) => ({ materials: s.materials.filter(m => m.id !== id) })),
  setOutputResolution: (res) => set({ outputResolution: res }),
  setCurrentMaskColor: (color: string) => set({ currentMaskColor: color }),  // ✅ 新增
  addMask: (mask: MaskRegion) => set((s) => ({ masks: [mask, ...s.masks], selectedMaskId: mask.id })),
  selectMask: (id: string) => set({ selectedMaskId: id }),
  updateMask: (id: string, partial: Partial<MaskRegion>) => set((s) => ({ 
    masks: s.masks.map(m => m.id === id ? { ...m, ...partial, updatedAt: Date.now() } : m) 
  })),
  removeMask: (id: string) => set((s) => ({ 
    masks: s.masks.filter(m => m.id !== id), 
    selectedMaskId: s.selectedMaskId === id ? undefined : s.selectedMaskId 
  })),
  toggleMaskVisibility: (id: string) => set((s) => ({
    masks: s.masks.map(m => m.id === id ? { ...m, visible: !m.visible } : m)
  })),
  clearAllMasks: () => set({ masks: [], selectedMaskId: undefined }),
  addTask: (task: Task) => set((s) => ({ tasks: [task, ...s.tasks] })),
  updateTask: (id: string, partial: Partial<Task>) => set((s) => ({
    tasks: s.tasks.map(t => t.id === id ? { ...t, ...partial } : t)
  })),
  setPrompt: (p) => set({ prompt: p }),
  setModel: (m) => set({ model: m }),
}))
