import React, { useEffect, useRef, useState } from 'react'
import { Stage, Layer, Rect, Image as KonvaImage, Line } from 'react-konva'
import { useAppStore } from '../store'

const MainCanvas: React.FC = () => {
  const stageRef = useRef<any>(null)
  const baseImage = useAppStore(s => s.baseImage)
  const baseMeta = useAppStore(s => s.baseMeta)
  const setBaseImage = useAppStore(s => s.setBaseImage)
  const setBaseMeta = useAppStore(s => s.setBaseMeta)
  const addMaterials = useAppStore(s => s.addMaterials)
  const baseFileRef = useRef<HTMLInputElement>(null)
  const materialFileRef = useRef<HTMLInputElement>(null)
  const masks = useAppStore(s => s.masks)
  const addMask = useAppStore(s => s.addMask)
  const [scale, setScale] = useState(1)
  const [stageSize, setStageSize] = useState({ width: 1024, height: 768 })
  const [imgEl, setImgEl] = useState<HTMLImageElement | null>(null)
  const [drawingPoints, setDrawingPoints] = useState<Array<{ x: number; y: number }>>([])
  const [isDrawing, setIsDrawing] = useState(false)

  useEffect(() => {
    if (!baseImage) return
    const img = new window.Image()
    img.crossOrigin = 'anonymous'
    img.src = baseImage
    img.onload = () => {
      setImgEl(img)
      setStageSize({ width: img.width, height: img.height })
      setBaseMeta({ width: img.width, height: img.height })
    }
  }, [baseImage])
  const onWheel = (e: any) => {
    e.evt.preventDefault()
    const stage = stageRef.current
    if (!stage) return
    const oldScale = stage.scaleX() || 1
    const pointer = stage.getPointerPosition()
    const scaleBy = 1.05
    const newScale = e.evt.deltaY < 0 ? oldScale * scaleBy : oldScale / scaleBy
    const mousePointTo = {
      x: (pointer.x - stage.x()) / oldScale,
      y: (pointer.y - stage.y()) / oldScale,
    }
    stage.scale({ x: newScale, y: newScale })
    const newPos = {
      x: pointer.x - mousePointTo.x * newScale,
      y: pointer.y - mousePointTo.y * newScale,
    }
    stage.position(newPos)
    stage.batchDraw()
  }

  const smoothPoints = (pts: Array<{ x: number; y: number }>, window = 4) => {
    if (pts.length <= window) return pts
    const out: Array<{ x: number; y: number }> = []
    for (let i = 0; i < pts.length; i++) {
      const start = Math.max(0, i - window + 1)
      const slice = pts.slice(start, i + 1)
      const x = slice.reduce((s, p) => s + p.x, 0) / slice.length
      const y = slice.reduce((s, p) => s + p.y, 0) / slice.length
      out.push({ x, y })
    }
    return out
  }

  const handleMouseDown = () => {
    const stage = stageRef.current
    const p = stage.getPointerPosition()
    setDrawingPoints([{ x: p.x, y: p.y }])
    setIsDrawing(true)
  }
  const handleMouseMove = () => {
    if (!isDrawing) return
    const stage = stageRef.current
    const p = stage.getPointerPosition()
    setDrawingPoints(prev => smoothPoints([...prev, { x: p.x, y: p.y }], 4))
  }
  const handleMouseUp = () => {
    setIsDrawing(false)
  }

  const saveMask = () => {
    const w = baseMeta?.width ?? stageSize.width
    const h = baseMeta?.height ?? stageSize.height
    if (drawingPoints.length < 3) return
    const canvas = document.createElement('canvas')
    canvas.width = w
    canvas.height = h
    const ctx = canvas.getContext('2d')!
    ctx.fillStyle = 'black'
    ctx.fillRect(0, 0, w, h)
    ctx.beginPath()
    const first = drawingPoints[0]
    ctx.moveTo(first.x, first.y)
    for (const pt of drawingPoints.slice(1)) ctx.lineTo(pt.x, pt.y)
    ctx.closePath()
    ctx.fillStyle = 'white'
    ctx.fill()
    const dataUrl = canvas.toDataURL('image/png')
    const id = `mask_${Date.now()}`
    const now = Date.now()
    addMask({ 
      id, 
      name: `蒙版 ${masks.length + 1}`,
      description: '',
      path: { points: drawingPoints }, 
      maskData: dataUrl, 
      action: 'generation', 
      referenceLink: null, 
      controlMode: 'content', 
      strength: 1.0, 
      promptSuffix: '',
      color: '#FF0000',
      label: '',
      shape: 'freehand',
      visible: true,
      createdAt: now,
      updatedAt: now
    })
    setDrawingPoints([])
  }
  return (
    <div className="canvas">
      <div style={{ position: 'absolute', top: 12, left: 12, display: 'flex', gap: 8, zIndex: 10 }}>
        <button className="button" onClick={() => baseFileRef.current?.click()}>上传主图</button>
        <input ref={baseFileRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={(e) => { const f = e.target.files?.[0]; if (f) setBaseImage(URL.createObjectURL(f)) }} />
        <button className="button" onClick={() => materialFileRef.current?.click()}>上传素材</button>
        <input ref={materialFileRef} type="file" accept="image/*" multiple style={{ display: 'none' }} onChange={(e) => { const files = e.target.files; if (!files) return; const assets = Array.from(files).map((f,i)=>({ id: `ref_${Date.now()}_${i}`, url: URL.createObjectURL(f), preprocess: 'none' as const })); addMaterials(assets) }} />
        <button className="button" onClick={saveMask} disabled={drawingPoints.length < 3}>保存为蒙版</button>
      </div>
      <Stage
        ref={stageRef}
        width={stageSize.width}
        height={stageSize.height}
        onWheel={onWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        draggable
      >
        <Layer>
          {imgEl ? (
            <KonvaImage image={imgEl} x={0} y={0} />
          ) : (
            <Rect x={10} y={10} width={100} height={100} fill="#2d3340" stroke="#6b7280" />
          )}
          {masks.map(m => (
            <Line key={m.id} points={m.path.points.flatMap(p => [p.x, p.y])} closed stroke="#3b82f6" fill="rgba(59,130,246,0.25)" />
          ))}
          {drawingPoints.length > 1 && (
            <Line points={drawingPoints.flatMap(p => [p.x, p.y])} stroke="#06b6d4" />
          )}
        </Layer>
      </Stage>
    </div>
  )
}

export default MainCanvas
