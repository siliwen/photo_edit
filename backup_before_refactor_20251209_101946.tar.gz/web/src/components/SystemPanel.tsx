import React from 'react'
import BaseImageCard from './cards/BaseImageCard'
import ReferenceImagesCard from './cards/ReferenceImagesCard'
import PromptAndModelCard from './cards/PromptAndModelCard'
import MaskBindingCard from './cards/MaskBindingCard'
import ActionBar from './cards/SubmitBar'

const SystemPanel: React.FC = () => {
  return (
    <div className="system-panel">
      <div className="cards-grid">
        <BaseImageCard />
        <ReferenceImagesCard />
      </div>
      <MaskBindingCard />
      <PromptAndModelCard />
      <ActionBar />
    </div>
  )
}

export default SystemPanel
