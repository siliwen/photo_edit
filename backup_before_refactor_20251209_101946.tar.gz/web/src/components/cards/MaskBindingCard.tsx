import React from 'react'
import { useAppStore } from '../../store'

const MaskBindingCard: React.FC = () => {
  const masks = useAppStore(s => s.masks)
  const materials = useAppStore(s => s.materials)
  const selectedMaskId = useAppStore(s => s.selectedMaskId)
  const selectMask = useAppStore(s => s.selectMask)
  const updateMask = useAppStore(s => s.updateMask)
  const removeMask = useAppStore(s => s.removeMask)

  const selectedMask = masks.find(m => m.id === selectedMaskId)

  return (
    <div className="card">
      <div className="card-header">
        <div className="card-title">蒙版列表与绑定</div>
        <span className="tag optional">可选</span>
      </div>
      <div className="card-body">
        {masks.length === 0 && (
          <div style={{ color: '#9ca3af', fontSize: 14 }}>暂无蒙版，请在原始图片中绘制</div>
        )}
        
        {/* 蒙版列表 */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {masks.map(mask => (
            <div 
              key={mask.id} 
              onClick={() => selectMask(mask.id)}
              style={{
                padding: 12,
                border: selectedMaskId === mask.id ? '2px solid #3b82f6' : '1px solid #e5e5e5',
                borderRadius: 8,
                cursor: 'pointer',
                background: selectedMaskId === mask.id ? '#eff6ff' : '#fff'
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div 
                    style={{ 
                      width: 16, 
                      height: 16, 
                      background: mask.color || '#3b82f6', 
                      borderRadius: 4,
                      border: '1px solid #e5e5e5'
                    }} 
                  />
                  <span style={{ fontSize: 12, fontWeight: 600 }}>
                    {mask.action === 'generation' ? '🎨 内容生成' : mask.action === 'style_transfer' ? '🖌️ 风格迁移' : '🧹 物体消除'}
                  </span>
                  <span style={{ fontSize: 10, color: '#999' }}>({mask.shape || 'freehand'})</span>
                </div>
                <button 
                  className="button" 
                  onClick={(e) => { e.stopPropagation(); removeMask(mask.id) }}
                  style={{ padding: '2px 8px', fontSize: 12 }}
                >
                  删除
                </button>
              </div>
              {mask.referenceLink && (
                <div style={{ fontSize: 12, color: '#666' }}>绑定素材: {mask.referenceLink}</div>
              )}
              <div style={{ fontSize: 12, color: '#999' }}>
                {mask.controlMode} | 强度: {mask.strength}
              </div>
            </div>
          ))}
        </div>

        {/* 绑定与配置面板 */}
        {selectedMask && (
          <div style={{ marginTop: 16, padding: 16, background: '#f9fafb', borderRadius: 8 }}>
            <h4 style={{ fontSize: 14, fontWeight: 600, marginBottom: 12 }}>配置选中蒙版</h4>
            
            {/* 动作类型 */}
            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: 12, color: '#666', display: 'block', marginBottom: 4 }}>动作类型</label>
              <select 
                className="button"
                value={selectedMask.action}
                onChange={(e) => updateMask(selectedMask.id, { action: e.target.value as any })}
                style={{ width: '100%', padding: '6px 12px' }}
              >
                <option value="generation">内容生成 (Content)</option>
                <option value="style_transfer">风格迁移 (Style)</option>
                <option value="remove">物体消除 (Remove)</option>
              </select>
            </div>

            {/* 绑定素材 */}
            {selectedMask.action !== 'remove' && (
              <div style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 12, color: '#666', display: 'block', marginBottom: 4 }}>绑定参考图</label>
                <select 
                  className="button"
                  value={selectedMask.referenceLink || ''}
                  onChange={(e) => updateMask(selectedMask.id, { referenceLink: e.target.value || null })}
                  style={{ width: '100%', padding: '6px 12px' }}
                >
                  <option value="">不绑定</option>
                  {materials.map(m => (
                    <option key={m.id} value={m.id}>{m.id}</option>
                  ))}
                </select>
              </div>
            )}

            {/* 控制模式 */}
            {selectedMask.action !== 'remove' && (
              <div style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 12, color: '#666', display: 'block', marginBottom: 4 }}>控制模式</label>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button 
                    className="button"
                    onClick={() => updateMask(selectedMask.id, { controlMode: 'content' })}
                    style={{ 
                      flex: 1, 
                      background: selectedMask.controlMode === 'content' ? '#3b82f6' : '#fff',
                      color: selectedMask.controlMode === 'content' ? '#fff' : '#000'
                    }}
                  >
                    内容
                  </button>
                  <button 
                    className="button"
                    onClick={() => updateMask(selectedMask.id, { controlMode: 'style' })}
                    style={{ 
                      flex: 1,
                      background: selectedMask.controlMode === 'style' ? '#3b82f6' : '#fff',
                      color: selectedMask.controlMode === 'style' ? '#fff' : '#000'
                    }}
                  >
                    风格
                  </button>
                  <button 
                    className="button"
                    onClick={() => updateMask(selectedMask.id, { controlMode: 'structure' })}
                    style={{ 
                      flex: 1,
                      background: selectedMask.controlMode === 'structure' ? '#3b82f6' : '#fff',
                      color: selectedMask.controlMode === 'structure' ? '#fff' : '#000'
                    }}
                  >
                    结构
                  </button>
                </div>
              </div>
            )}

            {/* 强度滑块 */}
            {selectedMask.action !== 'remove' && (
              <div style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 12, color: '#666', display: 'block', marginBottom: 4 }}>
                  强度: {selectedMask.strength.toFixed(2)}
                </label>
                <input 
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={selectedMask.strength}
                  onChange={(e) => updateMask(selectedMask.id, { strength: parseFloat(e.target.value) })}
                  style={{ width: '100%' }}
                />
              </div>
            )}

            {/* 补充提示词 */}
            {selectedMask.action !== 'remove' && (
              <div>
                <label style={{ fontSize: 12, color: '#666', display: 'block', marginBottom: 4 }}>补充提示词</label>
                <input 
                  type="text"
                  className="button"
                  value={selectedMask.promptSuffix || ''}
                  onChange={(e) => updateMask(selectedMask.id, { promptSuffix: e.target.value })}
                  placeholder="例如: sitting on the table"
                  style={{ width: '100%', padding: '6px 12px' }}
                />
              </div>
            )}
            
            {/* 文字标签 */}
            <div style={{ marginTop: 12 }}>
              <label style={{ fontSize: 12, color: '#666', display: 'block', marginBottom: 4 }}>蒙版标签（可选）</label>
              <input 
                type="text"
                className="button"
                value={selectedMask.label || ''}
                onChange={(e) => updateMask(selectedMask.id, { label: e.target.value })}
                placeholder="例如: 前景人物、天空区域"
                style={{ width: '100%', padding: '6px 12px' }}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default MaskBindingCard
