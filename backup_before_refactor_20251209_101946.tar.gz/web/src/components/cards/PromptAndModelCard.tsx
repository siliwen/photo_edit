import React, { useMemo, useState } from 'react'
import { useAppStore } from '../../store'

const PromptAndModelCard: React.FC = () => {
  const prompt = useAppStore(s => s.prompt)
  const setPrompt = useAppStore(s => s.setPrompt)
  const model = useAppStore(s => s.model)
  const setModel = useAppStore(s => s.setModel)
  const baseMeta = useAppStore(s => s.baseMeta)
  const outputResolution = useAppStore(s => s.outputResolution)
  const setOutputResolution = useAppStore(s => s.setOutputResolution)
  const materials = useAppStore(s => s.materials)
  const masks = useAppStore(s => s.masks)
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [cursorPosition, setCursorPosition] = useState(0)
  const textareaRef = React.useRef<HTMLTextAreaElement>(null)

  const parseRes = (res: string) => { const [w, h] = res.split('x').map(Number); return { w: w || 3840, h: h || 2160 } }
  const [width, setWidth] = useState<number>(parseRes(outputResolution).w)
  const height = useMemo(() => {
    const r = baseMeta ? baseMeta.width / baseMeta.height : (parseRes(outputResolution).w / parseRes(outputResolution).h)
    return Math.round(width / r)
  }, [width, baseMeta])

  const handlePromptChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value
    const pos = e.target.selectionStart
    setPrompt(value)
    setCursorPosition(pos)
    
    // 检测 @ 或 # 触发智能选择
    const textBefore = value.slice(0, pos)
    const lastAtOrHash = Math.max(textBefore.lastIndexOf('@'), textBefore.lastIndexOf('#'))
    
    if (lastAtOrHash !== -1) {
      const afterSymbol = textBefore.slice(lastAtOrHash + 1)
      // 如果符号后没有空格，显示提示
      if (!/\s/.test(afterSymbol)) {
        setShowSuggestions(true)
        return
      }
    }
    setShowSuggestions(false)
  }

  const insertReference = (ref: string, type: 'material' | 'mask') => {
    if (!textareaRef.current) return
    const value = prompt || ''
    const pos = cursorPosition
    const textBefore = value.slice(0, pos)
    const textAfter = value.slice(pos)
    
    // 找到最后一个 @ 或 #
    const lastAtOrHash = Math.max(textBefore.lastIndexOf('@'), textBefore.lastIndexOf('#'))
    const newValue = value.slice(0, lastAtOrHash) + (type === 'material' ? `@${ref}` : `#${ref}`) + ' ' + textAfter
    setPrompt(newValue)
    setShowSuggestions(false)
    
    // 聚焦回输入框
    setTimeout(() => {
      textareaRef.current?.focus()
      const newPos = lastAtOrHash + ref.length + 2
      textareaRef.current?.setSelectionRange(newPos, newPos)
    }, 0)
  }

  return (
    <div className="card">
      <div className="card-header">
        <div className="card-title">效果描述与模型选择</div>
      </div>
      <div className="card-body" style={{ display: 'grid', gap: 12 }}>
        <label style={{ display: 'grid', gap: 6, position: 'relative' }}>
          <span>效果描述（必填）</span>
          <textarea 
            ref={textareaRef}
            className="input" 
            rows={4} 
            maxLength={500} 
            value={prompt || ''} 
            onChange={handlePromptChange}
            onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
            placeholder="例如：保持构图，改为卡通风格。使用 @ 选择素材， # 选择蒙版" 
          />
          <span style={{ fontSize: 12, color: '#9ca3af' }}>{prompt?.length || 0}/500 字符 | 提示：输入 @ 选择素材，# 选择蒙版</span>
          
          {/* 智能选择面板 */}
          {showSuggestions && (materials.length > 0 || masks.length > 0) && (
            <div style={{
              position: 'absolute',
              top: '100%',
              left: 0,
              right: 0,
              marginTop: 4,
              background: '#fff',
              border: '1px solid #e5e5e5',
              borderRadius: 8,
              padding: 8,
              maxHeight: 200,
              overflow: 'auto',
              zIndex: 1000,
              boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
            }}>
              {materials.length > 0 && (
                <div style={{ marginBottom: 8 }}>
                  <div style={{ fontSize: 12, color: '#666', marginBottom: 4, fontWeight: 600 }}>🖼️ 参考素材 (使用 @)</div>
                  {materials.map(m => (
                    <div 
                      key={m.id}
                      onClick={() => insertReference(m.id, 'material')}
                      style={{
                        padding: '6px 8px',
                        cursor: 'pointer',
                        borderRadius: 4,
                        fontSize: 12,
                        display: 'flex',
                        alignItems: 'center',
                        gap: 8
                      }}
                      onMouseEnter={(e) => e.currentTarget.style.background = '#f3f4f6'}
                      onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                    >
                      <span className="id-badge">{m.id}</span>
                      <span>素材</span>
                    </div>
                  ))}
                </div>
              )}
              {masks.length > 0 && (
                <div>
                  <div style={{ fontSize: 12, color: '#666', marginBottom: 4, fontWeight: 600 }}>🎨 蒙版区域 (使用 @颜色)</div>
                  {masks.map((m, idx) => {
                    // ✅ 找到颜色对应的中文名称
                    const colorMap: Record<string, string> = {
                      '#FF0000': '红色',
                      '#00FF00': '绿色',
                      '#0000FF': '蓝色',
                      '#FFFF00': '黄色',
                      '#00FFFF': '青色',
                      '#FF00FF': '品红',
                      '#FFFFFF': '白色'
                    }
                    const colorName = colorMap[m.color.toUpperCase()] || m.color
                    
                    return (
                      <div 
                        key={m.id}
                        onClick={() => insertReference(colorName, 'mask')}
                        style={{
                          padding: '6px 8px',
                          cursor: 'pointer',
                          borderRadius: 4,
                          fontSize: 12,
                          display: 'flex',
                          alignItems: 'center',
                          gap: 8
                        }}
                        onMouseEnter={(e) => e.currentTarget.style.background = '#f3f4f6'}
                        onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                      >
                        <span 
                          style={{
                            width: 16,
                            height: 16,
                            backgroundColor: m.color,
                            borderRadius: 2,
                            border: '1px solid #e5e5e5'
                          }}
                        />
                        <span className="id-badge">@{colorName}</span>
                        <span>{m.description || m.name || `蒙版 ${idx + 1}`}</span>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>
          )}
        </label>
        <label style={{ display: 'grid', gap: 6 }}>
          <span>可引用素材编号（在提示词中使用）</span>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {materials.map(m => (
              <span key={m.id} className="id-badge">{m.id}</span>
            ))}
            {materials.length === 0 && <span style={{ color: '#9ca3af' }}>无素材</span>}
          </div>
        </label>
        <label style={{ display: 'grid', gap: 6 }}>
          <span>输出尺寸</span>
          
          {/* ✅ 新增：预设比例选择器 */}
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <select 
              className="input" 
              style={{ flex: 1 }}
              onChange={(e) => {
                const value = e.target.value
                if (value === 'custom') return
                
                // 解析比例
                const [w, h] = value.split(':').map(Number)
                const ratio = w / h
                
                // 默认宽度 3840，按比例计算高度
                const newWidth = 3840
                const newHeight = Math.round(newWidth / ratio)
                setWidth(newWidth)
                setOutputResolution(`${newWidth}x${newHeight}`)
              }}
            >
              <option value="custom">自定义比例</option>
              <option value="16:9">16:9 横屏 (推荐)</option>
              <option value="9:16">9:16 竖屏</option>
              <option value="1:1">1:1 正方形</option>
              <option value="4:3">4:3 传统横屏</option>
              <option value="3:4">3:4 传统竖屏</option>
              <option value="21:9">21:9 超宽屏</option>
              <option value="2:3">2:3 竖向海报</option>
            </select>
            <button 
              className="button" 
              type="button" 
              onClick={() => { 
                const r = baseMeta ? (baseMeta.width / baseMeta.height) : (16/9)
                const h = Math.round(3840 / r)
                setWidth(3840)
                setOutputResolution(`3840x${h}`)
              }}
            >
              匹配主图比例
            </button>
          </div>
          
          {/* 自定义宽度输入 */}
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <label style={{ fontSize: 12, color: '#666', minWidth: 60 }}>宽度：</label>
            <input 
              className="input" 
              type="number" 
              min={256} 
              step={1} 
              value={width} 
              onChange={(e) => { 
                const v = Math.max(256, Number(e.target.value) || 0)
                setWidth(v)
                setOutputResolution(`${v}x${height}`)
              }} 
              style={{ flex: 1 }}
            />
            <span style={{ fontSize: 12, color: '#666' }}>px</span>
          </div>
          
          <div style={{ fontSize: 12, color: '#9ca3af' }}>
            高度将自动设为：{height}px，当前输出：{outputResolution}
          </div>
        </label>
      </div>
    </div>
  )
}

export default PromptAndModelCard
