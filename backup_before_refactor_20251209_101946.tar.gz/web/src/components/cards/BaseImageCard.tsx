import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Stage, Layer, Image as KonvaImage, Line } from 'react-konva'
import { useAppStore, MASK_COLORS } from '../../store'
import { uploadToOSS } from '../../utils/upload'

const BaseImageCard: React.FC = () => {
  const baseImage = useAppStore(s => s.baseImage)
  const setBaseImage = useAppStore(s => s.setBaseImage)
  const baseMeta = useAppStore(s => s.baseMeta)
  const setBaseMeta = useAppStore(s => s.setBaseMeta)
  const currentMaskColor = useAppStore(s => s.currentMaskColor)
  const setCurrentMaskColor = useAppStore(s => s.setCurrentMaskColor)
  
  // ✅ 重构：单一蒙版 + 多元素
  const [maskElements, setMaskElements] = useState<Array<{
    id: string
    type: 'brush' | 'rectangle' | 'circle'
    color: string
    points: Array<{ x: number; y: number }>
    brushSize: number
  }>>([])
  const [elementHistory, setElementHistory] = useState<Array<typeof maskElements>>([])  // 撤销历史
  
  const [drawMode, setDrawMode] = useState<'brush' | 'rectangle' | 'circle'>('brush')
  const [imgEl, setImgEl] = useState<HTMLImageElement | null>(null)
  const [drawingPoints, setDrawingPoints] = useState<Array<{ x: number; y: number }>>([])
  const [isDrawing, setIsDrawing] = useState(false)
  const [brushSize, setBrushSize] = useState(20)
  const [showMasks, setShowMasks] = useState(true)
  const [cropArea, setCropArea] = useState<{x: number, y: number, w: number, h: number} | null>(null)
  const [cropRatio, setCropRatio] = useState<'free' | '1:1' | '16:9' | '4:3'>('free')
  const [showTransformMenu, setShowTransformMenu] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)
  const stageRef = useRef<any>(null)
  const [containerWidth, setContainerWidth] = useState<number>(800)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    const resize = () => {
      if (containerRef.current) setContainerWidth(containerRef.current.clientWidth)
    }
    resize()
    window.addEventListener('resize', resize)
    return () => window.removeEventListener('resize', resize)
  }, [])

  // 点击外部关闭菜单
  useEffect(() => {
    const handleClick = () => setShowTransformMenu(false)
    if (showTransformMenu) {
      document.addEventListener('click', handleClick)
      return () => document.removeEventListener('click', handleClick)
    }
  }, [showTransformMenu])

  useEffect(() => {
    if (!baseImage) { setImgEl(null); return }
    const img = new window.Image()
    img.crossOrigin = 'anonymous'
    img.src = baseImage
    img.onload = () => setImgEl(img)
  }, [baseImage])

  const onSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]
    if (!f) return
    
    try {
      // 先预览本地
      const localUrl = URL.createObjectURL(f)
      setBaseImage(localUrl)
      
      // 上传到 OSS
      const ossUrl = await uploadToOSS(f)
      console.log('Base image uploaded to OSS:', ossUrl)
      setBaseImage(ossUrl)
      
      // 读取尺寸
      const img = new Image()
      img.onload = () => setBaseMeta({ width: img.width, height: img.height })
      img.src = ossUrl
    } catch (error) {
      console.error('Upload failed:', error)
      alert('图片上传失败，请重试')
    }
  }

  const meta = baseMeta || { width: imgEl?.width || 1024, height: imgEl?.height || 768 }
  const viewScale = useMemo(() => {
    if (!meta.width) return 1
    const maxW = containerWidth - 24
    return Math.min(1, maxW / meta.width)
  }, [containerWidth, meta.width])

  // ✅ 优化：多级平滑算法
  const smoothPoints = (pts: Array<{ x: number; y: number }>, window = 5) => {
    if (pts.length <= window) return pts
    const out: Array<{ x: number; y: number }> = []
    
    // 第一遍：移动平均平滑
    for (let i = 0; i < pts.length; i++) {
      const start = Math.max(0, i - Math.floor(window / 2))
      const end = Math.min(pts.length, i + Math.ceil(window / 2))
      const slice = pts.slice(start, end)
      const x = slice.reduce((s, p) => s + p.x, 0) / slice.length
      const y = slice.reduce((s, p) => s + p.y, 0) / slice.length
      out.push({ x, y })
    }
    
    // 第二遍：提取关键点，减少点数
    if (out.length > 10) {
      const simplified: Array<{ x: number; y: number }> = [out[0]]
      const tolerance = 2  // 距离阈值
      
      for (let i = 1; i < out.length - 1; i++) {
        const prev = simplified[simplified.length - 1]
        const curr = out[i]
        const dist = Math.sqrt(Math.pow(curr.x - prev.x, 2) + Math.pow(curr.y - prev.y, 2))
        
        if (dist > tolerance) {
          simplified.push(curr)
        }
      }
      simplified.push(out[out.length - 1])
      return simplified
    }
    
    return out
  }

  // 闭合自动吸附（如果终点距起点<20px则自动闭合）
  const autoClose = (pts: Array<{ x: number; y: number }>) => {
    if (pts.length < 3) return pts
    const first = pts[0]
    const last = pts[pts.length - 1]
    const dist = Math.sqrt(Math.pow(first.x - last.x, 2) + Math.pow(first.y - last.y, 2))
    if (dist < 20) {
      return [...pts, first]
    }
    return pts
  }

  const handleMouseDown = () => {
    if (editMode === 'view' || !stageRef.current) return
    const p = stageRef.current.getPointerPosition()
    const original = { x: p.x / viewScale, y: p.y / viewScale }
    setDrawingPoints([original])
    setIsDrawing(true)
  }
  
  const handleMouseMove = () => {
    if (!isDrawing || !stageRef.current) return
    const p = stageRef.current.getPointerPosition()
    let original = { x: p.x / viewScale, y: p.y / viewScale }
    
    // 裁剪模式：应用比例约束
    if (editMode === 'crop' && cropRatio !== 'free' && drawingPoints.length > 0) {
      const start = drawingPoints[0]
      const dx = original.x - start.x
      const dy = original.y - start.y
      
      let targetRatio = 1
      if (cropRatio === '16:9') targetRatio = 16 / 9
      else if (cropRatio === '4:3') targetRatio = 4 / 3
      
      // 根据拖拽方向确定尺寸
      if (Math.abs(dx) * targetRatio > Math.abs(dy)) {
        // 宽度优先
        original = { x: original.x, y: start.y + dx / targetRatio * Math.sign(dy || 1) }
      } else {
        // 高度优先
        original = { x: start.x + dy * targetRatio * Math.sign(dx || 1), y: original.y }
      }
    }
    
    // 几何形状和裁剪：只保留起点和当前点，实时预览
    if (editMode === 'rectangle' || editMode === 'circle' || editMode === 'crop') {
      setDrawingPoints([drawingPoints[0], original])
    } else {
      // ✅ 优化：自由绘制增强平滑
      setDrawingPoints(prev => {
        const newPoints = [...prev, original]
        // 实时平滑，但保留最后几个点未平滑，提高响应速度
        if (newPoints.length > 10) {
          const smoothed = smoothPoints(newPoints.slice(0, -3), 5)
          return [...smoothed, ...newPoints.slice(-3)]
        }
        return newPoints
      })
    }
  }
  
  const handleMouseUp = () => {
    setIsDrawing(false)
    // 裁剪模式：保存裁剪区域
    if (editMode === 'crop' && drawingPoints.length >= 2) {
      const p1 = drawingPoints[0]
      const p2 = drawingPoints[drawingPoints.length - 1]
      setCropArea({
        x: Math.min(p1.x, p2.x),
        y: Math.min(p1.y, p2.y),
        w: Math.abs(p2.x - p1.x),
        h: Math.abs(p2.y - p1.y)
      })
    }
  }

  // 执行裁剪
  const applyCrop = async () => {
    if (!cropArea || !imgEl) return
    
    const { x, y, w, h } = cropArea
    if (w < 10 || h < 10) {
      alert('裁剪区域太小，请重新选择')
      return
    }
    
    try {
      // 创建临时canvas进行裁剪
      const canvas = document.createElement('canvas')
      canvas.width = w
      canvas.height = h
      const ctx = canvas.getContext('2d')!
      
      // 绘制裁剪区域
      ctx.drawImage(imgEl, x, y, w, h, 0, 0, w, h)
      
      // 转换为blob并上传
      const blob = await new Promise<Blob>((resolve) => {
        canvas.toBlob((b) => resolve(b!), 'image/png')
      })
      
      const file = new File([blob], 'cropped.png', { type: 'image/png' })
      const ossUrl = await uploadToOSS(file)
      
      console.log('[裁剪] 裁剪完成，OSS URL:', ossUrl)
      
      // 更新主图和元数据
      setBaseImage(ossUrl)
      setBaseMeta({ width: w, height: h })
      
      // 清空蒙版和裁剪状态
      clearAllMasks()
      setCropArea(null)
      setDrawingPoints([])
      setEditMode('view')
      
      alert('裁剪成功！原图已替换为裁剪后的图片')
    } catch (error) {
      console.error('[裁剪] 失败:', error)
      alert('裁剪失败，请重试')
    }
  }

  // 旋转图片（顺时针90度）
  const rotateImage = async () => {
    if (!imgEl) return
    if (masks.length > 0 && !confirm('旋转后所有蒙版将清空，确定继续？')) return
    
    try {
      const canvas = document.createElement('canvas')
      const w = meta.width
      const h = meta.height
      
      // 旋转后宽高互换
      canvas.width = h
      canvas.height = w
      const ctx = canvas.getContext('2d')!
      
      // 平移到中心，旋转90度，再平移回来
      ctx.translate(h / 2, w / 2)
      ctx.rotate(Math.PI / 2)
      ctx.drawImage(imgEl, -w / 2, -h / 2, w, h)
      
      // 转换为blob并上传
      const blob = await new Promise<Blob>((resolve) => {
        canvas.toBlob((b) => resolve(b!), 'image/png')
      })
      
      const file = new File([blob], 'rotated.png', { type: 'image/png' })
      const ossUrl = await uploadToOSS(file)
      
      console.log('[旋转] 旋转完成，OSS URL:', ossUrl)
      
      // 更新主图和元数据（宽高互换）
      setBaseImage(ossUrl)
      setBaseMeta({ width: h, height: w })
      
      // 清空蒙版
      clearAllMasks()
      
      alert('旋转成功！原图已旋转90度')
    } catch (error) {
      console.error('[旋转] 失败:', error)
      alert('旋转失败，请重试')
    }
  }

  // 翻转图片
  const flipImage = async (direction: 'horizontal' | 'vertical') => {
    if (!imgEl) return
    if (masks.length > 0 && !confirm('翻转后所有蒙版将清空，确定继续？')) return
    
    try {
      const canvas = document.createElement('canvas')
      const w = meta.width
      const h = meta.height
      canvas.width = w
      canvas.height = h
      const ctx = canvas.getContext('2d')!
      
      if (direction === 'horizontal') {
        // 水平翻转
        ctx.translate(w, 0)
        ctx.scale(-1, 1)
      } else {
        // 垂直翻转
        ctx.translate(0, h)
        ctx.scale(1, -1)
      }
      
      ctx.drawImage(imgEl, 0, 0, w, h)
      
      // 转换为blob并上传
      const blob = await new Promise<Blob>((resolve) => {
        canvas.toBlob((b) => resolve(b!), 'image/png')
      })
      
      const file = new File([blob], 'flipped.png', { type: 'image/png' })
      const ossUrl = await uploadToOSS(file)
      
      console.log('[翻转] 翻转完成，OSS URL:', ossUrl)
      
      // 更新主图
      setBaseImage(ossUrl)
      
      // 清空蒙版
      clearAllMasks()
      
      alert(`${direction === 'horizontal' ? '水平' : '垂直'}翻转成功！`)
    } catch (error) {
      console.error('[翻转] 失败:', error)
      alert('翻转失败，请重试')
    }
  }

  const saveMask = () => {
    const w = meta.width
    const h = meta.height
    console.log('[蒙版保存] 开始保存，图片尺寸:', { w, h, drawingPoints: drawingPoints.length })
    
    // 修复：几何形状只需2个点
    const minPoints = (editMode === 'mask' || editMode === 'erase') ? 3 : 2
    if (!w || !h || drawingPoints.length < minPoints) {
      console.warn('[蒙版保存] 保存条件不满足:', { w, h, points: drawingPoints.length, minPoints })
      alert(`至少需要${minPoints}个点才能保存蒙版`)
      return
    }
    
    let finalPoints = drawingPoints
    let shape: 'freehand' | 'rectangle' | 'circle' | 'polygon' = 'freehand'
    
    // 几何形状处理
    if (editMode === 'rectangle' && drawingPoints.length >= 2) {
      const p1 = drawingPoints[0]
      const p2 = drawingPoints[drawingPoints.length - 1]
      finalPoints = [
        p1,
        { x: p2.x, y: p1.y },
        p2,
        { x: p1.x, y: p2.y },
        p1
      ]
      shape = 'rectangle'
    } else if (editMode === 'circle' && drawingPoints.length >= 2) {
      const p1 = drawingPoints[0]
      const p2 = drawingPoints[drawingPoints.length - 1]
      const radius = Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2))
      const circlePoints: Array<{ x: number; y: number }> = []
      for (let i = 0; i <= 32; i++) {
        const angle = (i / 32) * Math.PI * 2
        circlePoints.push({
          x: p1.x + radius * Math.cos(angle),
          y: p1.y + radius * Math.sin(angle)
        })
      }
      finalPoints = circlePoints
      shape = 'circle'
    } else {
      // 自动闭合
      finalPoints = autoClose(drawingPoints)
    }
    
    const canvas = document.createElement('canvas')
    canvas.width = w
    canvas.height = h
    const ctx = canvas.getContext('2d')!
    ctx.fillStyle = 'black'
    ctx.fillRect(0, 0, w, h)
    ctx.beginPath()
    const first = finalPoints[0]
    ctx.moveTo(first.x, first.y)
    for (const pt of finalPoints.slice(1)) ctx.lineTo(pt.x, pt.y)
    ctx.closePath()
    
    // 消除模式：扩边10-20px
    if (editMode === 'erase') {
      ctx.lineWidth = 15
      ctx.strokeStyle = 'white'
      ctx.stroke()
    }
    
    ctx.fillStyle = 'white'
    ctx.fill()
    const dataUrl = canvas.toDataURL('image/png')
    const id = `mask_${Date.now()}`
    const action = editMode === 'erase' ? 'remove' : 'generation'
    const now = Date.now()
    
    // 提示用户输入描述
    const description = maskDescription.trim() || prompt(
      `请输入蒙版描述（用于AI理解）：\n例如："Replace the sky with sunset" 或 "Remove the person"`
    ) || ''
    
    console.log('[蒙版保存] 生成蒙版数据:', { 
      id, 
      action, 
      shape, 
      description,
      pointsCount: finalPoints.length,
      dataUrlLength: dataUrl.length 
    })
    
    addMask({ 
      id,
      name: `蒙版 ${masks.length + 1}`,
      description,
      path: { points: finalPoints }, 
      maskData: dataUrl, 
      action, 
      referenceLink: null, 
      controlMode: 'content', 
      strength: 1.0, 
      promptSuffix: '',
      color: currentMaskColor,  // ✅ 使用currentMaskColor
      label: '',
      shape,
      visible: true,
      createdAt: now,
      updatedAt: now
    })
    
    console.log('[蒙版保存] 蒙版已添加到 store')
    setDrawingPoints([])
    setMaskDescription('')
    setEditMode('view')
    alert(`蒙版已保存！描述: ${description || '(无描述)'}`)
  }

  return (
    <div className="card">
      <div className="card-header">
        <div className="card-title">原始图片</div>
        <span className="tag required">必填</span>
      </div>
      <div className="card-body" ref={containerRef}>
        <div style={{ display: 'flex', gap: 8, marginBottom: 12, flexWrap: 'wrap', alignItems: 'center' }}>
          <button className="button" onClick={() => inputRef.current?.click()}>选择图片</button>
          <input ref={inputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={onSelect} />
          {baseImage && (
            <>
              {/* 图片编辑工具 */}
              <div style={{ position: 'relative' }}>
                <button className="button" onClick={(e) => {
                  e.stopPropagation()
                  setShowTransformMenu(!showTransformMenu)
                }}>
                  ↻ 旋转/翻转 ▾
                </button>
                {showTransformMenu && (
                  <div style={{
                    position: 'absolute',
                    top: '100%',
                    left: 0,
                    marginTop: 4,
                    background: 'white',
                    border: '1px solid #e5e5e5',
                    borderRadius: 6,
                    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                    zIndex: 10,
                    minWidth: 140
                  }}>
                    <button 
                      className="button"
                      onClick={() => {
                        setShowTransformMenu(false)
                        rotateImage()
                      }}
                      style={{ 
                        display: 'block', 
                        width: '100%', 
                        textAlign: 'left', 
                        padding: '8px 12px',
                        border: 'none',
                        borderRadius: 0,
                        borderBottom: '1px solid #f0f0f0'
                      }}
                    >
                      ↻ 顺时针90°
                    </button>
                    <button 
                      className="button"
                      onClick={() => {
                        setShowTransformMenu(false)
                        flipImage('horizontal')
                      }}
                      style={{ 
                        display: 'block', 
                        width: '100%', 
                        textAlign: 'left', 
                        padding: '8px 12px',
                        border: 'none',
                        borderRadius: 0,
                        borderBottom: '1px solid #f0f0f0'
                      }}
                    >
                      ⇄ 水平翻转
                    </button>
                    <button 
                      className="button"
                      onClick={() => {
                        setShowTransformMenu(false)
                        flipImage('vertical')
                      }}
                      style={{ 
                        display: 'block', 
                        width: '100%', 
                        textAlign: 'left', 
                        padding: '8px 12px',
                        border: 'none',
                        borderRadius: 0
                      }}
                    >
                      ⇕ 垂直翻转
                    </button>
                  </div>
                )}
              </div>
              <button className="button" onClick={() => {
                if (editMode === 'crop') {
                  setEditMode('view')
                  setCropArea(null)
                  setDrawingPoints([])
                } else {
                  if (masks.length > 0 && !confirm('裁剪后所有蒙版将清空，确定继续？')) {
                    return
                  }
                  setEditMode('crop')
                  setCropArea(null)
                  setDrawingPoints([])
                }
              }}>
                {editMode === 'crop' ? '退出裁剪' : '✂️ 裁剪'}
              </button>
              {editMode === 'crop' && (
                <>
                  <select 
                    value={cropRatio} 
                    onChange={(e) => {
                      setCropRatio(e.target.value as any)
                      setCropArea(null)
                      setDrawingPoints([])
                    }}
                    style={{ padding: '4px 8px', fontSize: 12, border: '1px solid #e5e5e5', borderRadius: 4 }}
                  >
                    <option value="free">自由比侏</option>
                    <option value="1:1">1:1 正方形</option>
                    <option value="16:9">16:9 宽屏</option>
                    <option value="4:3">4:3 传统</option>
                  </select>
                  {cropArea && (
                    <button className="button" onClick={applyCrop} style={{ background: '#10b981', color: 'white' }}>
                      ✔️ 确认裁剪 ({Math.round(cropArea.w)}x{Math.round(cropArea.h)})
                    </button>
                  )}
                </>
              )}
              <div style={{ width: 1, height: 20, background: '#e5e5e5' }} />
              {/* 蒙版工具 */}
              <button className="button" onClick={() => setEditMode(editMode === 'mask' ? 'view' : 'mask')}>
                {editMode === 'mask' ? '退出' : '🖌️ 自由绘制'}
              </button>
              <button className="button" onClick={() => setEditMode(editMode === 'rectangle' ? 'view' : 'rectangle')}>
                {editMode === 'rectangle' ? '退出' : '■ 矩形'}
              </button>
              <button className="button" onClick={() => setEditMode(editMode === 'circle' ? 'view' : 'circle')}>
                {editMode === 'circle' ? '退出' : '● 圆形'}
              </button>
              <button className="button" onClick={() => setEditMode(editMode === 'erase' ? 'view' : 'erase')}>
                {editMode === 'erase' ? '退出' : '🧹 消除'}
              </button>
              {editMode !== 'view' && (
                <>
                  <button className="button" onClick={saveMask} disabled={drawingPoints.length < ((editMode === 'mask' || editMode === 'erase') ? 3 : 2)}>
                    保存
                  </button>
                  <input 
                    type="text" 
                    placeholder="蒙版描述(可选)"
                    value={maskDescription}
                    onChange={(e) => setMaskDescription(e.target.value)}
                    style={{ 
                      padding: '4px 8px', 
                      fontSize: 12, 
                      border: '1px solid #e5e5e5', 
                      borderRadius: 4,
                      width: 180
                    }}
                  />
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                    <label style={{ fontSize: 12, color: '#666' }}>笔刷:</label>
                    <input 
                      type="range" 
                      min="5" 
                      max="50" 
                      value={brushSize} 
                      onChange={(e) => setBrushSize(Number(e.target.value))}
                      style={{ width: 80 }}
                    />
                    <span style={{ fontSize: 12, color: '#666' }}>{brushSize}px</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                    <label style={{ fontSize: 12, color: '#666' }}>蒙版颜色:</label>
                    {MASK_COLORS.map(color => (
                      <button
                        key={color.id}
                        onClick={() => setCurrentMaskColor(color.hex)}
                        title={color.name}
                        style={{
                          width: 28,
                          height: 28,
                          backgroundColor: color.hex,
                          border: currentMaskColor === color.hex ? '3px solid #000' : '2px solid #e5e5e5',
                          borderRadius: 4,
                          cursor: 'pointer',
                          transition: 'all 0.2s',
                          boxShadow: currentMaskColor === color.hex ? '0 0 0 2px #fff, 0 0 8px rgba(0,0,0,0.3)' : 'none'
                        }}
                      />
                    ))}
                  </div>
                </>
              )}
              {masks.length > 0 && (
                <>
                  <button className="button" onClick={() => setShowMasks(!showMasks)}>
                    {showMasks ? '隐藏蒙版' : '显示蒙版'}
                  </button>
                  <button className="button" onClick={() => setShowMaskList(!showMaskList)}>
                    {showMaskList ? '隐藏列表' : `蒙版列表(${masks.length})`}
                  </button>
                  <button className="button" onClick={() => {
                    if (confirm(`确定清空所有 ${masks.length} 个蒙版吗？`)) {
                      clearAllMasks()
                      alert('所有蒙版已清空')
                    }
                  }}>
                    清空蒙版
                  </button>
                </>
              )}
            </>
          )}
        </div>
        {baseImage && (
          <Stage
            ref={stageRef}
            width={meta.width * viewScale}
            height={meta.height * viewScale}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
          >
            <Layer>
              {imgEl && <KonvaImage image={imgEl} x={0} y={0} scaleX={viewScale} scaleY={viewScale} />}
              {showMasks && masks.filter(m => m.visible).map(m => (
                <Line 
                  key={m.id} 
                  points={m.path.points.flatMap(p => [p.x * viewScale, p.y * viewScale])} 
                  closed 
                  stroke={selectedMaskId === m.id ? '#f59e0b' : (m.color || '#3b82f6')} 
                  strokeWidth={selectedMaskId === m.id ? 3 : 2}
                  fill={m.action === 'remove' ? 'rgba(239,68,68,0.2)' : `${m.color || '#3b82f6'}40`}
                  onClick={() => selectMask(m.id)}
                />
              ))}
              {/* 实时绘制预览 */}
              {drawingPoints.length > 1 && (() => {
                // 矩形预览：绘制矩形框
                if (editMode === 'rectangle') {
                  const p1 = drawingPoints[0]
                  const p2 = drawingPoints[drawingPoints.length - 1]
                  const rectPoints = [
                    p1,
                    { x: p2.x, y: p1.y },
                    p2,
                    { x: p1.x, y: p2.y },
                    p1
                  ]
                  return (
                    <Line 
                      points={rectPoints.flatMap(p => [p.x * viewScale, p.y * viewScale])} 
                      stroke={currentMaskColor}  // ✅ 使用currentMaskColor
                      strokeWidth={2}
                      fill={`${currentMaskColor}20`}  // ✅ 使用currentMaskColor
                      closed
                    />
                  )
                }
                
                // 圆形预览：绘制圆形轮廓
                if (editMode === 'circle') {
                  const p1 = drawingPoints[0]
                  const p2 = drawingPoints[drawingPoints.length - 1]
                  const radius = Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2))
                  const circlePoints: Array<{ x: number; y: number }> = []
                  for (let i = 0; i <= 32; i++) {
                    const angle = (i / 32) * Math.PI * 2
                    circlePoints.push({
                      x: p1.x + radius * Math.cos(angle),
                      y: p1.y + radius * Math.sin(angle)
                    })
                  }
                  return (
                    <>
                      {/* 圆形轮廓 */}
                      <Line 
                        points={circlePoints.flatMap(p => [p.x * viewScale, p.y * viewScale])} 
                        stroke={currentMaskColor}  // ✅ 使用currentMaskColor
                        strokeWidth={2}
                        fill={`${currentMaskColor}20`}  // ✅ 使用currentMaskColor
                        closed
                      />
                      {/* 中心点标记 */}
                      <Line 
                        points={[
                          (p1.x - 5) * viewScale, p1.y * viewScale,
                          (p1.x + 5) * viewScale, p1.y * viewScale
                        ]}
                        stroke={currentMaskColor}  // ✅ 使用currentMaskColor
                        strokeWidth={2}
                      />
                      <Line 
                        points={[
                          p1.x * viewScale, (p1.y - 5) * viewScale,
                          p1.x * viewScale, (p1.y + 5) * viewScale
                        ]}
                        stroke={currentMaskColor}  // ✅ 使用currentMaskColor
                        strokeWidth={2}
                      />
                      {/* 半径线 */}
                      <Line 
                        points={[
                          p1.x * viewScale, p1.y * viewScale,
                          p2.x * viewScale, p2.y * viewScale
                        ]}
                        stroke={currentMaskColor}  // ✅ 使用currentMaskColor
                        strokeWidth={1}
                        dash={[5, 5]}
                      />
                    </>
                  )
                }
                
                // 裁剪预览：绘制裁剪框和蒙版
                if (editMode === 'crop') {
                  const p1 = drawingPoints[0]
                  const p2 = drawingPoints[drawingPoints.length - 1]
                  const x1 = Math.min(p1.x, p2.x)
                  const y1 = Math.min(p1.y, p2.y)
                  const x2 = Math.max(p1.x, p2.x)
                  const y2 = Math.max(p1.y, p2.y)
                  const w = x2 - x1
                  const h = y2 - y1
                  
                  return (
                    <>
                      {/* 裁剪框 */}
                      <Line 
                        points={[
                          x1 * viewScale, y1 * viewScale,
                          x2 * viewScale, y1 * viewScale,
                          x2 * viewScale, y2 * viewScale,
                          x1 * viewScale, y2 * viewScale
                        ]}
                        stroke="#10b981"
                        strokeWidth={3}
                        closed
                      />
                      {/* 裁剪区域高亮 */}
                      <Line 
                        points={[
                          x1 * viewScale, y1 * viewScale,
                          x2 * viewScale, y1 * viewScale,
                          x2 * viewScale, y2 * viewScale,
                          x1 * viewScale, y2 * viewScale
                        ]}
                        fill="rgba(16, 185, 129, 0.1)"
                        closed
                      />
                      {/* 尺寸标注背景 */}
                      <Line 
                        points={[
                          (x1 + w / 2 - 30) * viewScale, (y1 + 10) * viewScale,
                          (x1 + w / 2 + 30) * viewScale, (y1 + 10) * viewScale,
                          (x1 + w / 2 + 30) * viewScale, (y1 + 25) * viewScale,
                          (x1 + w / 2 - 30) * viewScale, (y1 + 25) * viewScale
                        ]}
                        fill="rgba(0, 0, 0, 0.7)"
                        closed
                      />
                    </>
                  )
                }
                
                // 自由绘制/消除：显示笔触
                return (
                  <Line 
                    points={drawingPoints.flatMap(p => [p.x * viewScale, p.y * viewScale])} 
                    stroke={editMode === 'erase' ? '#ef4444' : currentMaskColor}  // ✅ 使用currentMaskColor
                    strokeWidth={brushSize * viewScale}
                    lineCap="round"
                    lineJoin="round"
                  />
                )
              })()}
            </Layer>
          </Stage>
        )}
        
        {/* 蒙版列表面板 */}
        {showMaskList && masks.length > 0 && (
          <div style={{ 
            marginTop: 12, 
            padding: 12, 
            background: '#f9fafb', 
            borderRadius: 8,
            maxHeight: 300,
            overflowY: 'auto'
          }}>
            <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 8, color: '#374151' }}>
              蒙版列表 ({masks.length})
            </div>
            {masks.map((mask, index) => (
              <div 
                key={mask.id}
                style={{ 
                  padding: 8, 
                  marginBottom: 8,
                  background: selectedMaskId === mask.id ? '#eff6ff' : 'white',
                  border: `1px solid ${selectedMaskId === mask.id ? '#3b82f6' : '#e5e7eb'}`,
                  borderRadius: 6,
                  cursor: 'pointer'
                }}
                onClick={() => selectMask(mask.id)}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                      <div 
                        style={{ 
                          width: 16, 
                          height: 16, 
                          borderRadius: 3,
                          background: mask.color,
                          border: '1px solid #d1d5db'
                        }} 
                      />
                      <span style={{ fontSize: 13, fontWeight: 500, color: '#111827' }}>
                        {mask.name || `蒙版 ${masks.length - index}`}
                      </span>
                      <span style={{ 
                        fontSize: 11, 
                        padding: '2px 6px',
                        borderRadius: 3,
                        background: mask.action === 'remove' ? '#fee2e2' : '#dbeafe',
                        color: mask.action === 'remove' ? '#991b1b' : '#1e40af'
                      }}>
                        {mask.action === 'remove' ? '消除' : '生成'}
                      </span>
                      <span style={{ fontSize: 11, color: '#6b7280' }}>
                        {mask.shape === 'rectangle' ? '■ 矩形' : 
                         mask.shape === 'circle' ? '● 圆形' : 
                         mask.shape === 'polygon' ? '⬡ 多边形' : '✍️ 自由'}
                      </span>
                    </div>
                    {mask.description && (
                      <div style={{ fontSize: 12, color: '#6b7280', marginLeft: 22 }}>
                        "{mask.description}"
                      </div>
                    )}
                  </div>
                  <div style={{ display: 'flex', gap: 4 }}>
                    <button 
                      className="button"
                      onClick={(e) => {
                        e.stopPropagation()
                        toggleMaskVisibility(mask.id)
                      }}
                      style={{ padding: '4px 8px', fontSize: 11 }}
                      title={mask.visible ? '隐藏' : '显示'}
                    >
                      {mask.visible ? '👁️' : '🚫'}
                    </button>
                    <button 
                      className="button"
                      onClick={(e) => {
                        e.stopPropagation()
                        const newDesc = prompt('修改蒙版描述：', mask.description)
                        if (newDesc !== null) {
                          updateMask(mask.id, { description: newDesc })
                        }
                      }}
                      style={{ padding: '4px 8px', fontSize: 11 }}
                      title="编辑"
                    >
                      ✏️
                    </button>
                    <button 
                      className="button"
                      onClick={(e) => {
                        e.stopPropagation()
                        if (confirm(`确定删除这个蒙版吗？`)) {
                          removeMask(mask.id)
                        }
                      }}
                      style={{ padding: '4px 8px', fontSize: 11, color: '#ef4444' }}
                      title="删除"
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        
        {/* 裁剪模式提示 */}
        {editMode === 'crop' && (
          <div style={{ fontSize: 12, color: '#9ca3af', marginTop: 8, lineHeight: 1.6 }}>
            <div style={{ marginBottom: 4 }}>
              💡 <strong>裁剪模式：</strong>
            </div>
            <div>• 鼠标拖拽选择裁剪区域，松开后点击“确认裁剪”按钮</div>
            <div>• 支持比例约束：自由/1:1/16:9/4:3</div>
            <div style={{ marginTop: 4, color: '#ef4444', opacity: 0.9 }}>
              ⚠️ 裁剪后原图将被替换，所有蒙版将被清空
            </div>
          </div>
        )}
        
        {editMode !== 'view' && editMode !== 'crop' && (
          <div style={{ fontSize: 12, color: '#9ca3af', marginTop: 8, lineHeight: 1.6 }}>
            <div style={{ marginBottom: 4 }}>
              💡 <strong>操作说明：</strong>
            </div>
            {editMode === 'mask' && (
              <div>• <strong>自由绘制：</strong>按住鼠标拖动绘制任意形状，松开鼠标后点击"保存"按钮。终点距起点{'<'}20px时自动闭合。</div>
            )}
            {editMode === 'rectangle' && (
              <div>• <strong>矩形工具：</strong>点击起点，拖动到对角终点，松开鼠标。画布会实时显示矩形预览框。</div>
            )}
            {editMode === 'circle' && (
              <div>• <strong>圆形工具：</strong>点击圆心位置，向外拖动定义半径，松开鼠标。画布会实时显示圆形轮廓和半径线。</div>
            )}
            {editMode === 'erase' && (
              <div>• <strong>消除模式：</strong>圈选要删除的区域，系统将自动扩边10-20px以提供背景纹理，提升修补自然度。</div>
            )}
            <div style={{ marginTop: 4, opacity: 0.8 }}>
              ℹ️ 蒙版将按主图尺寸1:1栅格化为单通道黑白图，确保位置精度。
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default BaseImageCard
