import React from 'react'
import { useAppStore, MASK_COLORS } from '../../store'
import { uploadDataURL } from '../../utils/upload'

// ✅ RGB蒙版合成函数
const compositeMasksToRGB = async (masks: any[], baseWidth: number, baseHeight: number): Promise<string | null> => {
  if (masks.length === 0) return null
  
  const canvas = document.createElement('canvas')
  canvas.width = baseWidth
  canvas.height = baseHeight
  const ctx = canvas.getContext('2d')!
  
  // 黑色背景
  ctx.fillStyle = '#000000'
  ctx.fillRect(0, 0, canvas.width, canvas.height)
  
  console.log(`[RGB蒙版合成] 开始合成 ${masks.length} 个蒙版`)
  
  // 逐个叠加蒙版（使用 lighter 混合模式）
  for (const mask of masks) {
    await new Promise<void>((resolve, reject) => {
      const img = new Image()
      img.crossOrigin = 'anonymous'
      img.onload = () => {
        try {
          // 创建临时canvas应用颜色滤镜
          const tempCanvas = document.createElement('canvas')
          tempCanvas.width = baseWidth
          tempCanvas.height = baseHeight
          const tempCtx = tempCanvas.getContext('2d')!
          
          // 绘制原始蒙版（黑白）
          tempCtx.drawImage(img, 0, 0, baseWidth, baseHeight)
          
          // 获取像素数据
          const imageData = tempCtx.getImageData(0, 0, baseWidth, baseHeight)
          const data = imageData.data
          
          // 将白色区域替换为目标颜色
          const colorInfo = MASK_COLORS.find(c => c.hex === mask.color) || MASK_COLORS[0]
          const [r, g, b] = colorInfo.rgb
          
          for (let i = 0; i < data.length; i += 4) {
            const brightness = data[i]  // 只看 R 通道（黑白图）
            if (brightness > 128) {  // 白色区域
              data[i] = r
              data[i + 1] = g
              data[i + 2] = b
              data[i + 3] = 255
            } else {  // 黑色区域
              data[i] = 0
              data[i + 1] = 0
              data[i + 2] = 0
              data[i + 3] = 255
            }
          }
          
          tempCtx.putImageData(imageData, 0, 0)
          
          // 叠加到主 canvas（颜色相加混合）
          ctx.globalCompositeOperation = 'lighter'
          ctx.drawImage(tempCanvas, 0, 0)
          
          console.log(`[RGB蒙版合成] 已合成蒙版: ${mask.id}, 颜色: ${colorInfo.name} (${colorInfo.hex})`)
          resolve()
        } catch (error) {
          console.error(`[RGB蒙版合成] 处理失败:`, error)
          reject(error)
        }
      }
      img.onerror = () => {
        console.error(`[RGB蒙版合成] 加载失败: ${mask.id}`)
        reject(new Error(`Failed to load mask: ${mask.id}`))
      }
      img.src = mask.maskData
    })
  }
  
  const compositeDataUrl = canvas.toDataURL('image/png')
  console.log(`[RGB蒙版合成] 完成，总尺寸: ${canvas.width}x${canvas.height}`)
  return compositeDataUrl
}

const SubmitBar: React.FC = () => {
  const addTask = useAppStore(s => s.addTask)
  const updateTask = useAppStore(s => s.updateTask)
  const baseImage = useAppStore(s => s.baseImage)
  const baseMeta = useAppStore(s => s.baseMeta)  // ✅ 新增：获取图片尺寸
  const materials = useAppStore(s => s.materials)
  const outputResolution = useAppStore(s => s.outputResolution)
  const prompt = useAppStore(s => s.prompt)
  const model = useAppStore(s => s.model)
  const masks = useAppStore(s => s.masks)

  const submit = async () => {
    const id = `job_${Date.now()}`
    addTask({ id, title: `生成任务（${outputResolution}）`, status: 'PROCESSING', createdAt: Date.now() })
    
    try {
      // ✅ 先合成 RGB 蒙版
      let compositeMaskUrl: string | null = null
      if (masks.length > 0 && baseMeta) {
        console.log('[RGB蒙版] 检测到', masks.length, '个蒙版，开始合成...')
        const compositeDataUrl = await compositeMasksToRGB(masks, baseMeta.width, baseMeta.height)
        if (compositeDataUrl) {
          compositeMaskUrl = await uploadDataURL(compositeDataUrl, `composite_mask_${Date.now()}.png`)
          console.log('[RGB蒙版] 合成完成，已上传:', compositeMaskUrl)
        }
      }
      
      // ✅ 上传单个蒙版到 OSS（保留用于描述信息）
      const uploadedMasks = await Promise.all(
        masks.map(async (m) => {
          // 注意：单个蒙版不再上传，仅保留元数据
          console.log(`Mask ${m.id} metadata:`, { color: m.color, description: m.description })
          return {
            id: m.id,
            maskUrl: '',  // ✅ 不再上传单个蒙版
            description: m.description || '',
            action: m.action,
            referenceLink: m.referenceLink || null,
            controlMode: m.controlMode,
            strength: m.strength,
            promptSuffix: m.promptSuffix || '',
            label: m.label || '',
            color: m.color || '#FF0000'  // ✅ 颜色信息用于提示词组织
          }
        })
      )
      
      const payload = {
        project_id: String(Date.now()),
        base_image: baseImage,
        reference_assets: materials.map(a => ({ id: a.id, url: a.url, preprocess: a.preprocess })),
        mask_regions: uploadedMasks,
        composite_mask_url: compositeMaskUrl,  // ✅ 新增：合成后的RGB蒙版
        global_params: { output_resolution: outputResolution, seed: 42, model },
        prompt: prompt || '',
      }
      console.log('submit payload', payload)
      
      const res = await fetch('http://localhost:3001/api/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })
      const { taskId } = await res.json()
      
      // 轮询任务状态
      const pollTask = setInterval(async () => {
        const statusRes = await fetch(`http://localhost:3001/api/task/${taskId}`)
        const task = await statusRes.json()
        
        if (task.status === 'COMPLETE') {
          clearInterval(pollTask)
          updateTask(id, { status: 'COMPLETE', resultUrl: task.result })
          alert('任务完成')
        } else if (task.status === 'FAILED') {
          clearInterval(pollTask)
          updateTask(id, { status: 'FAILED' })
          alert(`任务失败：${task.error}`)
        }
      }, 2000)
    } catch (err) {
      console.error('Submit error:', err)
      updateTask(id, { status: 'FAILED' })
      alert('提交失败: ' + (err as Error).message)
    }
  }

  return (
    <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
      <button className="button" onClick={submit} disabled={!baseImage || !prompt}>提交生成</button>
    </div>
  )
}

export default SubmitBar
