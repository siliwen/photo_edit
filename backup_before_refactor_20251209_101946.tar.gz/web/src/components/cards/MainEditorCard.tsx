import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Stage, Layer, Image as KonvaImage, Line } from 'react-konva'
import { useAppStore } from '../../store'

const MainEditorCard: React.FC = () => {
  const baseImage = useAppStore(s => s.baseImage)
  const baseMeta = useAppStore(s => s.baseMeta)
  const masks = useAppStore(s => s.masks)
  const addMask = useAppStore(s => s.addMask)

  const containerRef = useRef<HTMLDivElement>(null)
  const stageRef = useRef<any>(null)
  const [imgEl, setImgEl] = useState<HTMLImageElement | null>(null)
  const [containerWidth, setContainerWidth] = useState<number>(800)
  const [drawingPoints, setDrawingPoints] = useState<Array<{ x: number; y: number }>>([])
  const [isDrawing, setIsDrawing] = useState(false)

  useEffect(() => {
    const resize = () => {
      if (containerRef.current) setContainerWidth(containerRef.current.clientWidth)
    }
    resize()
    window.addEventListener('resize', resize)
    return () => window.removeEventListener('resize', resize)
  }, [])

  useEffect(() => {
    if (!baseImage) { setImgEl(null); return }
    const img = new window.Image()
    img.crossOrigin = 'anonymous'
    img.src = baseImage
    img.onload = () => setImgEl(img)
  }, [baseImage])

  const meta = baseMeta || { width: imgEl?.width || 1024, height: imgEl?.height || 768 }
  const viewScale = useMemo(() => {
    if (!meta.width) return 1
    const maxW = containerWidth - 24
    return Math.min(1, maxW / meta.width)
  }, [containerWidth, meta.width])

  const smoothPoints = (pts: Array<{ x: number; y: number }>, window = 4) => {
    if (pts.length <= window) return pts
    const out: Array<{ x: number; y: number }> = []
    for (let i = 0; i < pts.length; i++) {
      const start = Math.max(0, i - window + 1)
      const slice = pts.slice(start, i + 1)
      const x = slice.reduce((s, p) => s + p.x, 0) / slice.length
      const y = slice.reduce((s, p) => s + p.y, 0) / slice.length
      out.push({ x, y })
    }
    return out
  }

  const handleMouseDown = () => {
    if (!stageRef.current) return
    const p = stageRef.current.getPointerPosition()
    const original = { x: p.x / viewScale, y: p.y / viewScale }
    setDrawingPoints([original])
    setIsDrawing(true)
  }
  const handleMouseMove = () => {
    if (!isDrawing || !stageRef.current) return
    const p = stageRef.current.getPointerPosition()
    const original = { x: p.x / viewScale, y: p.y / viewScale }
    setDrawingPoints(prev => smoothPoints([...prev, original], 4))
  }
  const handleMouseUp = () => setIsDrawing(false)

  const saveMask = () => {
    const w = meta.width
    const h = meta.height
    if (!w || !h || drawingPoints.length < 3) return
    const canvas = document.createElement('canvas')
    canvas.width = w
    canvas.height = h
    const ctx = canvas.getContext('2d')!
    ctx.fillStyle = 'black'
    ctx.fillRect(0, 0, w, h)
    ctx.beginPath()
    const first = drawingPoints[0]
    ctx.moveTo(first.x, first.y)
    for (const pt of drawingPoints.slice(1)) ctx.lineTo(pt.x, pt.y)
    ctx.closePath()
    ctx.fillStyle = 'white'
    ctx.fill()
    const dataUrl = canvas.toDataURL('image/png')
    const id = `mask_${Date.now()}`
    const now = Date.now()
    addMask({ 
      id, 
      name: `蒙版 ${masks.length + 1}`,
      description: '',
      path: { points: drawingPoints }, 
      maskData: dataUrl, 
      action: 'generation', 
      referenceLink: null, 
      controlMode: 'content', 
      strength: 1.0, 
      promptSuffix: '',
      color: '#FF0000',
      label: '',
      shape: 'freehand',
      visible: true,
      createdAt: now,
      updatedAt: now
    })
    setDrawingPoints([])
  }

  return (
    <div className="card" ref={containerRef}>
      <div className="card-header">
        <div className="card-title">原图编辑（蒙版互动）</div>
      </div>
      <div className="card-body">
        {!baseImage && <div style={{ color: '#9ca3af' }}>请先在上方“原始图片”卡片上传主图</div>}
        {baseImage && (
          <Stage
            ref={stageRef}
            width={meta.width * viewScale}
            height={meta.height * viewScale}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
          >
            <Layer>
              {imgEl && <KonvaImage image={imgEl} x={0} y={0} scaleX={viewScale} scaleY={viewScale} />}
              {masks.map(m => (
                <Line key={m.id} points={m.path.points.flatMap(p => [p.x * viewScale, p.y * viewScale])} closed stroke="#3b82f6" fill="rgba(59,130,246,0.25)" />
              ))}
              {drawingPoints.length > 1 && (
                <Line points={drawingPoints.flatMap(p => [p.x * viewScale, p.y * viewScale])} stroke="#06b6d4" />
              )}
            </Layer>
          </Stage>
        )}
        <div style={{ marginTop: 12 }}>
          <button className="button" onClick={saveMask} disabled={drawingPoints.length < 3}>保存为蒙版</button>
        </div>
        <div style={{ fontSize: 12, color: '#9ca3af', marginTop: 8 }}>
          蒙版将按主图尺寸（1:1）栅格化为单通道黑白图，确保位置精度。
        </div>
      </div>
    </div>
  )
}

export default MainEditorCard
