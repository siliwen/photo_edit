import React, { useMemo, useState } from 'react'
import { useAppStore, Task } from '../store'
import Modal from './Modal'

const statusColor: Record<string, string> = {
  PENDING: '#9ca3af',
  PROCESSING: '#f59e0b',
  COMPLETE: '#10b981',
  FAILED: '#ef4444',
}

const TaskList: React.FC = () => {
  const tasks = useAppStore(s => s.tasks)
  const updateTask = useAppStore(s => s.updateTask)
  const [preview, setPreview] = useState<{ open: boolean; task?: Task }>({ open: false })

  const sorted = useMemo(() => tasks.sort((a, b) => b.createdAt - a.createdAt), [tasks])

  return (
    <div>
      <div className="panel-header">任务列表</div>
      <div className="panel-body">
        <div className="list">
          {sorted.length === 0 && <div style={{ color: '#9ca3af' }}>暂无任务</div>}
          {sorted.map(t => (
            <div key={t.id} className="item" style={{ justifyContent: 'space-between' }}>
              <div style={{ display: 'grid' }}>
                <span style={{ fontSize: 12, color: '#9ca3af' }}>{new Date(t.createdAt).toLocaleTimeString()}</span>
                <span style={{ fontWeight: 600 }}>{t.title}</span>
              </div>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <span style={{ fontSize: 12, color: statusColor[t.status] }}>{t.status}</span>
                {t.status === 'COMPLETE' && t.resultUrl && (
                  <button className="button" onClick={() => setPreview({ open: true, task: t })}>查看</button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
      <Modal open={preview.open} onClose={() => setPreview({ open: false })}>
        {preview.task?.resultUrl ? (
          <img src={preview.task.resultUrl} style={{ maxWidth: '100%', height: 'auto', borderRadius: 8 }} />
        ) : (
          <div style={{ color: '#9ca3af' }}>暂无预览</div>
        )}
      </Modal>
    </div>
  )
}

export default TaskList
